package br.com.celo.minhacarteira;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhacarteiraApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinhacarteiraApplication.class, args);
	}

}
