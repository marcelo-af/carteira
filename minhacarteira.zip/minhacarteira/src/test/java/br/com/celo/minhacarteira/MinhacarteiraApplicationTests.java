package br.com.celo.minhacarteira;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinhacarteiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
